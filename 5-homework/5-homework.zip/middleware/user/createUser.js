/**
 * Creates a user
 */

module.exports = (objrep) => {
  return (req, res, next) => {
    console.log('createUser - ')
    next()
  }
}
