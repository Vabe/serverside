/**
 * Get one project
 * @returns project
 */

module.exports = (objrep) => {
  return (req, res, next) => {
    console.log('getProject - ')
    return next()
  }
}
