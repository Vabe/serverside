/**
 * Updates one project
 * (might be replaced by expanding the createProject)
 */

module.exports = (objrep) => {
  return (req, res, next) => {
    console.log('updateProject - ')
    next()
  }
}
