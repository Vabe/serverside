/**
 * Deletes project from database, redirects to 'projects.html'
 */

module.exports = (objrep) => {
  return (req, res, next) => {
    console.log('deleteProject - ')
    next()
  }
}
